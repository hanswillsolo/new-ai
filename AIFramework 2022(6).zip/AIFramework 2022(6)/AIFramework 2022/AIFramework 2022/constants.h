#pragma once

#define SCREEN_WIDTH 1024
#define SCREEN_HEIGHT 768